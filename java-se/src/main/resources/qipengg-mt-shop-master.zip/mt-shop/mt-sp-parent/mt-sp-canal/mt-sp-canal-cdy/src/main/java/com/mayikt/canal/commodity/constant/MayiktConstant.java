package com.mayikt.canal.commodity.constant;

/**
 * @author 余胜军
 * @ClassName Constant
 * @qq 644064779
 * @addres www.mayikt.com
 * 微信:yushengjun644
 */
public interface MayiktConstant {
    String CANAL_UPDATE = "UPDATE";
    String CANAL_DELETE = "DELETE";
    String CANAL_INSERT = "INSERT";
}
