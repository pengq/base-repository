package com.mayikt.impl.spike.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mayikt.impl.spike.entity.CommodityOrderEntity;

/**
 * @author 余胜军
 * @ClassName CommodityOrderMapper
 * @qq 644064779
 * @addres www.mayikt.com
 * @createTime 2021年05月06日 18:43:00
 */

public interface CommodityOrderMapprer extends BaseMapper<CommodityOrderEntity> {
}
