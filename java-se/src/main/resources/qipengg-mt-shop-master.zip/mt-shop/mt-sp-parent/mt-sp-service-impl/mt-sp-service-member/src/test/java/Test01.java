import com.mayikt.api.utils.MD5Util;

public class Test01 {
    public static void main(String[] args) {
        String mayikt = MD5Util.MD5("mayikt");
        System.out.println(mayikt);
    }
}
