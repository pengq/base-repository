package com.mayikt.api.integral.impl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mayikt.api.integral.impl.entity.IntegralInfoEntity;


public interface IntegralInfoMapper extends BaseMapper<IntegralInfoEntity> {
}