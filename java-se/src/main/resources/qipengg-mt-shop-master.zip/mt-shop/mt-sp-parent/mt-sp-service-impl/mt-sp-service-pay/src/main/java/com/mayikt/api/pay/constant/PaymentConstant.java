package com.mayikt.api.pay.constant;

public interface PaymentConstant {
    //  支付成功
    Integer PAYMENT_STATUS_SUCCESS = 1;
    //  待支付
    Integer PAYMENT_STATUS_FAIL = 0;
    Integer RPC_PAY_SUCCESS = 10000;
}