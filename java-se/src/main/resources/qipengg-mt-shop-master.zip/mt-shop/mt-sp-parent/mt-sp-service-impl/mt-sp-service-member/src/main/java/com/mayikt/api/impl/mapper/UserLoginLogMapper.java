package com.mayikt.api.impl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mayikt.api.impl.entity.UserLoginLogDo;

public interface UserLoginLogMapper extends BaseMapper<UserLoginLogDo> {
}