package com.mayikt.integral.consumer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mayikt.integral.consumer.entity.IntegralInfoEntity;

public interface IntegralInfoMapper extends BaseMapper<IntegralInfoEntity> {
}